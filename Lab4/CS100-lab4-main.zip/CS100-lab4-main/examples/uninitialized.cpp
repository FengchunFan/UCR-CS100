#include <iostream>
using namespace std;

int main() {
    int x;
    cout << x << endl;

    return 0;
}
