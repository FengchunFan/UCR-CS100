int main() {
    int *p = new int[10];
    p[10] = 1;

    return 0;
}
