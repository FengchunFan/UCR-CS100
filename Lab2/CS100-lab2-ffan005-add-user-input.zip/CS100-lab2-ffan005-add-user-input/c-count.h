#include <iostream>

// count function should go here

